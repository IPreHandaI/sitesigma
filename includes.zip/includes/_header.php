<header>

<ul class="nav">
  <li class="nav-item">
    <a class="nav-link active" href="index.php">Site sigma</a>
  </li>
  <li class="nav-item">
    <a class="nav-link" href="index.php">Home</a>
  </li>
  <li class="nav-item">
    <a class="nav-link" href="produtos.php">Produtos</a>
  </li>
  <li class="nav-item">
    <a class="nav-link" href="contato.php">Contato</a>
  </li>
</ul>

</header>